# Release Notes Process

The release notes process is based on WorkItem-Tagging and automatically updates the Release Notes Wiki page via DevOps Pipeline.

## Items to be created manually (once)

- Release Notes Wiki Page
- Subfolder under _Shared Queries_ folder
- Parent Template Query under _Shared Queries/YourSubfolder_

## Process Overview

Prerequisite is, that the relevant Work Items for the Release have been tagged with 'vnext' and are closed (status Done).

<div align=center>

::: mermaid
graph TD
    A(Pipeline 'Release Notes' triggered with the version number as input parameter) --> B(Collect PBIs/Bugs tagged with 'vnext' and Status=Done)
    B --> C(Remove tag 'vnext' and add the new version number as tag to all Work Items)
    C --> D(Create new Query based on a Query Template and add the new version tag as condition)
    D --> E(Extend the Release Notes Wiki page with the chapter for the new version and add the new Query)
:::

</div>

## Work Items Tag (_vnext_)

Weather we create release notes manually or on automated way, we need somehow to identify and mark which Work Items belongs to upcoming Public Release and related release version. From this reason, when we start to work on a new Release, we need to tag all our PBI's and Bugs with the Tag _vnext_ within Azure DevOps Backlog. By doing this each time we create new Work Item, we mark and prepare all ongoing Work Items to be processed by our Release Notes Pipeline at the end of the successful Release roll-out.
It is important to know, that only Work Items of type:

- Product Backlog Item
- Bug

which satisfy following conditions, are going to be a part of Release Notes Document:

- State must be **Done**
- Area Path must equals or be under **yourRoothAreaPath**
- Work Item must be tagged with tag **vnext**

_Note: You can change the conditions in the parent template query for another Work Item types or another Work Items states, etc._

## Release Notes Pipeline

In order to automate creation of release reports (release notes) on the basis of _vnext_ tagged data from our Azure DevOps System, we use a _Release Notes (On Demand) Pipeline_.

### Azure DevOps Product Backlog Item as Source of Data

The Work Items which will be part of the release notes are retrieved from our Azure DevOps system.
Each WorkItem of the type _Product Backlog Item_ or _Bug_, properly tagged and fulfilling the given conditions. This can be changed and extended to the Features or/and Epics by manipulating the ParentQuery.

## Trigger

_Release Notes_ Pipeline is not a CI Pipeline, it is designed to be triggered only On Demand. The Pipeline expects one important value from us before we trigger it. This value is _Release Package Version Number_ (e.g. v.1.0.0.0).

The Release Package Version Number is predefined, global variable within our YAML template definition. Default value is empty string, but we are allowed and obligated to override this value each time we want to run the pipeline.

### Release Package Version Number Variable

**So, what should we enter there?**
Normally, we should enter the version of our current Release (Examples v1.0.0.0, 1.0.0.0 etc.).
No matter if you prefix the version with small _v_, the pipeline will take care about this and add it if it is not there.

_Note: We can't add same version number twice, because the version number will be validated against Azure DevOps and if any existing Query and Release Notes Sections are found with this version, execution of the pipeline will be stopped with appropriate Error Message._

**When we should enter the Release Package Version Number value?**
This value should be entered just before we are to execute our Release Notes Pipeline, meaning at the end of the Release Roll-Out when we have a need to have the Release Notes Document, but also before we start creating and tagging new Release Work Items.

## Release Notes Artifacts

Once we triggered our pipeline and it run successfully, we are able to observe following objects created or updated:

- Query, recording all the Work Items which belongs to our Release
- Wiki Page _Release Notes_

_Note: Please, do not delete or update manually any of the artifacts created by our pipeline without consulting some of the Azure DevOps administrators._

### Query

Queries for single Releases, created by pipeline (via Azure DevOps REST API) should be saved in Azure DevOps under _yourorganization -> yourproject -> Boards -> Queries -> Shared Queries -> Shared Release Notes Queries Folder -> ReleaseNotesTemplate_
Accordingly, please set the parameters value in YAML files to correspond to your Environment:

- ParentQueryFolder (relative folder path, where parentquery is created)
- ParentQueryName (the name of parent template query)
- WikiPath (relative path to the Release Notes wiki page)
- WikiItemPath (relative path to the Release Notes wiki page with .md extension)
- WikiProjectName (Wiki Project Name, ends with .wiki => e.g. Wiki-Home.wiki)
  
### Release Notes Wiki Page

_Release Notes Wiki Page_ is the final Release Document which can be printed, copied and shared with colleagues and client or customer.

## Print - Export As PDF (Release Notes Document)

Finally, when the Release Document Wiki Page is updated with your Release Notes, we can print it and export it to the PDF as well.
From right top corner, select the button with three dots and then select option _Print_.

Print Preview Window appears. If we just want to print the document out, then we select the blue _Print_ button.
If we want to export Wiki Page as PDF, we should select option _Print using system dialog (Ctrl+Shift+P)_.

## Security and Permissions

Please ensure following permissions are set within your Azure DevOps project:

- Project Build Service User is added to the project _Contributors_ group
- Navigate to the Project Settings -> Pipelines Settings. In section General, please **disable** option _Limit job authorization scope to referenced Azure DevOps repositories_
- Navigate to the Boards -> Queries -> Shared Queries -> {your custom shared subfolder} and select option Security for the folder. Set Permission _Contribute_ to allow for the Contributors group.
