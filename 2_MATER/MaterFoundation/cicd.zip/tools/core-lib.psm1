using namespace System.Management.Automation

# Utility

function EnsureEmptyFolder {
    param([Parameter(Mandatory = $true)] [string] $Path)

    if (!(Test-Path $SolutionPath)) {
        New-Item -ItemType Directory -Path $SolutionPath -Force
    }
    Remove-Item -Path "$SolutionPath\*" -Force -Recurse
}

function Get-FrameworkConfiguration {
    param([string] $Path)

    Write-Verbose "Loading configuration from Configuration.json at `"$Path`""
    $config = Get-Content $path -Raw | ConvertFrom-Json

    return $config
}

function Get-ConnectionString {
    param(
        [Parameter(Mandatory = $true)]
        [string]
        $ConfigurationPath,

        [Parameter(Mandatory = $true)]
        [string]
        $EnvironmentName
    )

    Write-Verbose "Trying to get connection string for env `"$EnvironmentName`" from `"$ConfigurationPath`""

    $config = Get-FrameworkConfiguration -Path $ConfigurationPath

    $envMember = $config.Environments | Get-Member -Name $EnvironmentName
    $envConfig = $config.Environments | Select-Object -ExpandProperty $envMember.Name

    $ConnectionString = $envConfig.ConnectionString
    if ([string]::IsNullOrEmpty($connectionString)) {
        throw "ConnectionString for `"$EnvironmentName`" for branch `"$BranchName`" is empty"

    }
    Write-Verbose "ConnectionString: $ConnectionString"
    
    $parts = [System.Text.RegularExpressions.Regex]::Matches($ConnectionString, "{{(.*?)}}")
    foreach ($part in $parts) {
        $partName = $part.Groups[0].Value
        $partNameClean = $part.Groups[1].Value

        $var = Get-Variable -Scope Global -Name "DSSF_SECRET_$partNameClean" -ErrorAction Ignore
        if ($null -eq $var) {
            $value = Read-Host "Enter value for secret variable $($partName)"
            $ConnectionString = $ConnectionString.Replace($partName, $value)
    
            Set-Variable -Scope Global -Name "DSSF_SECRET_$partNameClean" -Value $value
        }
        else {
            $ConnectionString = $ConnectionString.Replace($partName, $var.Value)
        }
    }

    return $ConnectionString
}

function Get-SolutionName {
    param([string] $Path, [string] $Type)

    $solution = Get-Solution -Path $Path -Type $Type
    return $solution.Name
}

function Get-Solution {
    param([string] $Path, [string] $Type)

    Write-Host "Trying to get solution for solution type `"$Type`""
    $solutions = Get-Solutions -Path $Path 
    $solution = $solutions | 
    Where-Object { $_.Type -eq $Type } | 
    Select-Object -First 1

    if ($null -eq $solution) {
        throw "Solution with type `"$Type`" not found in EnvironmentConfig at `"$Path`""
    }

    return $solution
}

function Get-Solutions {
    param([string] $Path)

    Write-Host "Trying to get solutions from `"$Path`""
    $config = Get-FrameworkConfiguration -Path $Path
    return $config.Solutions
}

function Get-CodeSolutionConfiguration {
    param([string] $Path, [string] $Type)

    Write-Host "Determining solution for type = $Type"
    $config = Get-FrameworkConfiguration -Path $Path
    return $config.CodeSolutions.$Type;
}

$IsNuGetInstalled = $false

function Assert-NuGetIsInstalled {
    if($IsNuGetInstalled) { return }

    Install-NuGet
    $IsNuGetInstalled = $true
}

# NuGet
function Install-NuGet {
    Write-InformationColored "Installing NuGet... " -NoNewLine

    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    Write-Verbose "Start install NuGet"
    $progressPreference = "SilentlyContinue"
    $sourceNugetExe = "https://dist.nuget.org/win-x86-commandline/latest/nuget.exe"
    #$proxyurl = ([System.Net.WebRequest]::GetSystemWebproxy()).GetProxy($sourceNugetExe)
    $targetNugetExe = "$([System.IO.Path]::GetTempFileName()).exe"
    Invoke-WebRequest $sourceNugetExe -OutFile $targetNugetExe
    #Invoke-WebRequest $sourceNugetExe -Proxy $proxyurl -OutFile $targetNugetExe
    Set-Alias nuget $targetNugetExe -Scope Global
    $progressPreference = "Continue"
    Write-Verbose "Finished NuGet install"
    
    Write-InformationColored "Done" -ForegroundColor Green
}

function Get-InstalledNuGetPackageVersion {
    param([string] $CSProjectPath, [string] $PackageName)

    if (!(Test-Path $CSProjectPath)) {
        throw "The C# project at location `"$CSProjectPath`" could not be found!"
    }

    [xml] $doc = Get-Content $CSProjectPath
    foreach ($node in $doc.DocumentElement.GetElementsByTagName("PackageReference")) {
        $cPackageName = $node.Attributes["Include"].Value
        if ($cPackageName -eq $PackageName) {
            $version = $node.Attributes["Version"].Value
            if ($null -eq $version) {
                $version = $node.ChildNodes[0].InnerText
            }

            return $version
        }
    }

    throw "Unable to find PackageReference for `"$PackageName`" in `"$CSProjectPath`""
}

function Install-NewestNuGetPackage {
    param([string] $PackageName, [string] $ToolPath)

    if ($null -eq (Get-Command "nuget" -ErrorAction SilentlyContinue)) {
        Install-NuGet
    }

    Write-InformationColored "Installing $PackageName... " -NoNewline

    $NugetGlobalPackagePath = "$($env:USERPROFILE)\.nuget\packages"
    $PackageRawPath = [System.IO.Path]::Combine($NugetGlobalPackagePath, $PackageName)

    if (!(Test-Path $PackageRawPath)) {
        nuget install $PackageName -OutputDirectory $NugetGlobalPackagePath | Out-Null
    }
    else {
        Write-InformationColored "Already installed" -ForegroundColor Green
    }

    $PackageFolder = Get-ChildItem -Directory -Path $PackageRawPath | Sort-Object -Descending -Property Name | Select-Object -First 1

    $FullToolPath = [System.IO.Path]::Combine($PackageFolder.FullName, $ToolPath)
    if (!(Test-Path $FullToolPath)) {
        throw "Unable to find tool `"$FullToolPath`""
    }

    return $FullToolPath
}

function Install-NuGetPackage {
    param([string] $PackageName, [string] $PackageVersion, [string] $ToolPath)

    if ($null -eq (Get-Command "nuget" -ErrorAction SilentlyContinue)) {
        Install-NuGet
    }

    Write-Verbose "Getting nuget tool path:"
    Write-Verbose "PackageName: $PackageName"
    Write-Verbose "PackageVersion: $PackageVersion"
    Write-Verbose "NugetConfigPath: $NugetConfigPath"
    Write-Verbose "ToolPath: $ToolPath"

    $NugetGlobalPackagePath = (nuget locals global-packages -list).Substring(17)
    Write-Verbose "Nuget global package path: $NugetGlobalPackagePath"

    $PackagePath = ""
    if ("" -eq $PackageVersion) {
        $PackagePath = [System.IO.Path]::Combine($NugetGlobalPackagePath, $PackageName)
    }
    else {
        $PackagePath = [System.IO.Path]::Combine($NugetGlobalPackagePath, $PackageName, $PackageVersion)
    }
    Write-Verbose "Package path: $PackagePath"

    if (!(Test-Path $PackagePath)) {
        Write-Information "Installing nuget package."

        if ("" -eq $PackageVersion) {
            nuget install $PackageName -OutputDirectory $NugetGlobalPackagePath | Out-Null
        } else {
            nuget install $PackageName -Version $PackageVersion -OutputDirectory $NugetGlobalPackagePath | Out-Null
        }
    }

    if ("" -eq $PackageVersion) {
        $PackagePath = Get-ChildItem -Directory -Path $PackagePath | Sort-Object -Descending -Property CreationTime | Select-Object -First 1 -ExpandProperty Fullname
    }

    $FullToolPath = [System.IO.Path]::Combine($PackagePath, $ToolPath)
    if (!(Test-Path $FullToolPath)) {
        throw "Unable to find tool `"$FullToolPath`""
    }

    return $FullToolPath
}

function Install-NuGetPackageFromProject {
    param([string] $PackageName, [string] $ToolPath, [string] $CSProjectPath)

    Write-Verbose "Getting nuget tool path (easy):"
    Write-Verbose "PackageName: $PackageName"
    Write-Verbose "NugetConfigPath: $NugetConfigPath"
    Write-Verbose "ToolPath: $ToolPath"
    Write-Verbose "CSProjectPath: $CSProjectPath"

    $version = Get-InstalledNuGetPackageVersion -CSProjectPath $CSProjectPath -PackageName $PackageName
    Write-Verbose "Nuget Package version: $version"

    $resolvedPath = Install-NuGetPackage -PackageName $PackageName -PackageVersion $version -ToolPath $ToolPath
    Write-Verbose "Path to nuget package: $resolvedPath"

    return $resolvedPath
}

# Solutions
function Expand-CrmSolution {
    param(
        [string] $SolutionPath, 
        [string] $SolutionName, 
        [string] $BasePath, 
        [string] $NugetConfigPath,
        [string] $CSProjectPath = $null
    )

    $TargetPackageName = "Microsoft.CrmSdk.CoreTools"
    
    $toolPath = Install-NuGetPackageFromProject `
        -PackageName $TargetPackageName `
        -ToolPath "content\bin\coretools\SolutionPackager.exe" `
        -CSProjectPath $CSProjectPath

    $UnpackPath = "$BasePath\Solutions\$SolutionName\src"
    EnsureEmptyFolder -Path $UnpackPath

    $command = $toolPath
    $command += " /action:Extract"
    $command += " /zipfile:`"$SolutionPath`""
    $command += " /folder:`"$UnpackPath`""

    try {
        Write-Host "Removing any .dll file in the extracted solution"
        Get-ChildItem -Path $UnpackPath -Filter *.dll -Recurse | Remove-Item
    }
    catch { }

    Invoke-Expression $command
}

function Compress-CrmSolution {
    param([string] $UnpackedPath, [string] $PackedPath, [string] $PackageType, [string] $CSProjectPath, [string] $NugetConfigPath)

    $TargetPackageName = "Microsoft.CrmSdk.CoreTools"
		
    $toolPath = Install-NuGetPackageFromProject `
        -PackageName $TargetPackageName `
        -NugetConfigPath $NugetConfigPath `
        -ToolPath "content\bin\coretools\SolutionPackager.exe" `
        -CSProjectPath $CSProjectPath

    $command = $toolPath
    $command += " /action:Pack"
    $command += " /packagetype:$PackageType"
    $command += " /zipfile:`"$PackedPath`""
    $command += " /folder:`"$UnpackedPath`""

    $command | Invoke-Expression
}

function Set-NetworkSettings {
    param ([string] $Proxy, [bool] $TLS12 = $true)

    if ($TLS12 -eq $true) {
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    }
    
    if (-not [string]::IsNullOrEmpty($Proxy)) {
        [System.Net.WebRequest]::DefaultWebProxy = New-Object System.Net.WebProxy($Proxy)
    }
}

function Push-NextSolutionVersion {
    param([string]$SolutionName, [string]$SolutionPath)

    $solutionVersionString = Get-SolutionVersion `
        -SolutionUniqueName $SolutionName
    $solutionVersion = [version]::Parse($solutionVersionString)

    $solutionXmlFile = "$SolutionPath/src/Other/Solution.xml"
    [xml]$doc = Get-Content $solutionXmlFile
    $gitSolutionVersion = [version]::Parse($doc.ImportExportXml.SolutionManifest.Version)

    $newVersion = [version]::new($gitSolutionVersion.Major, $gitSolutionVersion.Minor, $gitSolutionVersion.Build + 1)

    Write-Host "Version in Dataverse: $solutionVersion"
    Write-Host "Version in git: $gitSolutionVersion"
    Write-Host "New version: $newVersion"

    <# TODO: Improve error handling
      Logic is quite quirky that way. If something happens between increasing the solution version in Dataverse and the actual git push of the solution
      it will fail the next time although nothing was done.
      
      Idea: Save the version in an env variable and add a step after a successful git push to increase the solution version in dataverse
    #>

    if ($gitSolutionVersion -lt $solutionVersion) {
        throw @"
                Version of solution $SolutionName in Dataverse is greater than the source controlled version. 
                Validate the version, unpack the solution and integrate the changes into version control.
"@
    }

    Set-SolutionVersion `
        -Version $newVersion `
        -SolutionUniqueName $SolutionName

    $doc.ImportExportXml.SolutionManifest.Version = $newVersion.ToString()
    $doc.Save($solutionXmlFile)
}

function Get-NextSolutionVersion {
    param([string] $ConnectionString, [string] $SolutionName, [string] $BaseVersion)

    $solutionVersion = Get-SolutionVersion `
        -SolutionUniqueName $SolutionName

    $oldVersion = [version]::Parse($solutionVersion)
    $baseVer = [version]::Parse($BaseVersion)

    $newVersionBase = [version]::new($baseVer.Major, $baseVer.Minor, [int]::Parse((Get-Date -Format "yyyyMMdd")))
    $oldVersionBase = [version]::new($oldVersion.Major, $oldVersion.Minor, $oldVersion.Build)

    $newVersion = "0.0.0.1"
    if ($newVersionBase -gt $oldVersionBase) {
        $newVersion = $newVersionBase.ToString()
    }
    elseif ($newVersionBase -eq $oldVersionBase) {
        $newVersion = "$($newVersionBase.ToString(3)).$($oldVersion.Revision + 1)"
    }
    else {
        Write-Error "BaseVersion from Configuration.json is older than the current installed version"
    }

    Write-Host "SolutionName: $SolutionName, InstalledVersion: $oldVersion, VersionBase: $newVersionBase, NewVersion: $newVersion"

    return $newVersion
}

function Test-CrmSolutionExistsInGit {
    param([string] $BasePath, [string] $SolutionName)

    $path = Join-Path $BasePath $SolutionName

    $customizationsExists = Test-Path "$path/Other/Customizations.xml"
    $relationshipsExist = Test-Path "$path/Other/Relationships.xml"
    $solutionExists = Test-Path "$path/Other/Solution.xml"

    return $customizationsExists -and $relationshipsExist -and $solutionExists
}


# Executes the Deployment Tool.
function Invoke-DPA {
    param(
        [Parameter(Mandatory = $true)] [string]    $XMLLocation, 
        [Parameter(Mandatory = $true)] [hashtable] $Parameters, 
        [Parameter(Mandatory = $true)] [string]    $BasePath, 
        [Parameter(Mandatory = $true)] [string]    $CSProjectPath,
        [Parameter(Mandatory = $true)] [string]    $NugetConfigPath
    )

    $dmaToolPath = Install-NuGetPackageFromProject `
        -PackageName "Avanade.BizApps.Tools.DeploymentTool" `
        -NugetConfigPath $NugetConfigPath `
        -ToolPath "content/dpa.exe" `
        -CSProjectPath $CSProjectPath

    Write-Host "DPA Path: $dmaToolPath"

    $command = "& `"$dmaToolPath`""
    $command += " `"$XMLLocation`""
    foreach ($parameter in $Parameters.GetEnumerator()) {
        $command += " -$($parameter.Key):`"$($parameter.Value)`""
    }
    $command += " *>&1" # Powershell Stream Redirection (all streams to success stream)
    $command | Invoke-Expression | Tee-Object -Variable commandOutput

    if ($LASTEXITCODE -ne 0) {
        Write-Error "DPA execution failed! Please check the Error Message or contact your solution architect!"
        exit 1
    }
  
    Write-Host "DPA exectued sucessfully!"
}

function Get-DPACmdletLocation {
    return Install-NuGetPackageFromProject `
        -PackageName "Avanade.BizApps.Tools.DeploymentTool" `
        -ToolPath "content\Avanade.BizApps.Tools.DeploymentTool.Cmdlets.dll" `
        -CSProjectPath "$PSScriptRoot\..\..\src\Tools\Dataverse.Framework.Tools\Dataverse.Framework.Tools.csproj"
}

function Invoke-DMA {
    param(
        [Parameter(Mandatory = $true)] [hashtable] $Parameters, 
        [Parameter(Mandatory = $true)] [string]    $BasePath, 
        [Parameter(Mandatory = $true)] [string]    $CSProjectPath,
        [Parameter(Mandatory = $true)] [string]    $NugetConfigPath
    )

    $dmaToolPath = Install-NuGetPackageFromProject `
        -PackageName "Avanade.BizApps.Tools.DataModelAccelerator" `
        -NugetConfigPath $NugetConfigPath `
        -ToolPath "content/dma.exe" `
        -CSProjectPath $CSProjectPath

    Write-Host "DMA Path: $dmaToolPath"

    $command = "& `"$dmaToolPath`""
    $command += " `"$XMLLocation`""
    foreach ($parameter in $Parameters.GetEnumerator()) {
        $command += " -$($parameter.Key) `"$($parameter.Value)`""
    }
    $command += " *>&1" # Powershell Stream Redirection (all streams to success stream)
    $command | Invoke-Expression | Tee-Object -Variable commandOutput

    if ($LASTEXITCODE -ne 0) {
        Write-Error "DMA failed! Please check the Error Message or contact your solution architect!"
        exit 1
    }
  
    Write-Host "DMA exectued sucessfully!"
}

function Set-Preference {
    param($Invocation)

    $global:ErrorActionPreference = if ($Invocation.BoundParameters.Keys.Contains("ErrorAction")) {
        $Invocation.BoundParameters["ErrorAction"]
    }
    else { "Stop" }

    $global:WarningPreference = if ($Invocation.BoundParameters.Keys.Contains("WarningAction")) {
        $Invocation.BoundParameters["WarningAction"]
    }
    else { "Continue" }

    $global:VerbosePreference = if ($Invocation.BoundParameters.Keys.Contains("Verbose")) {
        "Continue"
    }
    else { "SilentlyContinue" }

    $global:InformationPreference = if ($Invocation.BoundParameters.Keys.Contains("InformationAction")) {
        $Invocation.BoundParameters["InformationAction"]
    }
    else { "Continue" }
}

function Invoke-Module {
    param([string] $Path, [switch] $Verbose)

    $verboseText = if ($Verbose.IsPresent) { 
        " -Verbose" 
    }
    else { "" }

    Invoke-Expression "& `"$Path`" -ErrorAction $global:ErrorActionPreference -WarningAction $global:WarningPreference -InformationAction $global:InformationPreference $verboseText"
}

function Test-PowerShellVersion {
    if ($PSVersionTable.PSEdition -eq "Core") {
        Write-InformationColored "It seems you're using PowerShell Core (Version 6 & later). Please open a PowerShell 5 window. D365CE SDK does not support .NET Core." -ForegroundColor Red
        Write-Host " "
        Exit 1
    }
}

function Write-InformationColored {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true, Position = 0)][Object]$MessageData,
        [ConsoleColor]$ForegroundColor = $Host.UI.RawUI.ForegroundColor,
        [ConsoleColor]$BackgroundColor = $Host.UI.RawUI.BackgroundColor,
        [Switch]$NoNewline
    )

    $msg = [HostInformationMessage]@{
        Message         = $MessageData
        ForegroundColor = $ForegroundColor
        BackgroundColor = $BackgroundColor
        NoNewline       = $NoNewline.IsPresent
    }

    Write-Information $msg
}

function Get-Choice {
    param(
        [string]    $Prompt,
        [string[]]  $Choices = @("Yes", "No"),
        [int]       $Default = -1
    )

    Write-Information $Prompt

    do {
        for ($i = 0; $i -lt $Choices.Count; $i++) {
            $choice = $Choices[$i] -replace "^&", ""

            if ($i -eq $Default) {
                Write-Information "[$i]`t$choice (Default)"
            }
            else {
                Write-Information "[$i]`t$choice"
            }
        }

        $selectedIndex = Read-Host -Prompt "Your choice"
        if ([string]::IsNullOrEmpty($selectedIndex)) {
            $selectedIndex = $Default
        }
        else {
            # If selected choice is not numeric, skip
            try {
                $selectedIndex = [int] $selectedIndex
            }
            catch {
                $selectedIndex = -1
            }
        }
    } until ($selectedIndex -ge 0 -and $selectedIndex -lt $Choices.Count)
    
    return $selectedIndex
}

function Read-TargetEnvironment {
    param(
        [Parameter(Mandatory = $true)]
        [string]
        $ConfigurationPath,

        [Parameter(Mandatory = $false)]
        [scriptblock]
        $Filter
    )

    Write-Information "`nWhich Environment do you want to use?`n"

    $config = Get-Content $ConfigurationPath -Raw | ConvertFrom-Json

    $environments = @($config.Environments.PSObject.Properties.Name)
    $count = $environments.Count

    while ($true) {
        $cnt = 0
        $environments | ForEach-Object {
            $valid = $false
            if ($null -eq $Filter) {
                $valid = $true
            }
            else {
                $valid = $Filter.Invoke($config.Environments.$_)
            }

            if ($valid) {
                Write-Information "[$cnt] $($_)"
                $cnt++
            }
        }
        $choice = Read-Host -Prompt "`nYour Choice"

        if ($choice -ge 0 -and $choice -le $count - 1) {
            Write-Host "Using Environment `"$($environments[$choice])`"`n"
            return $environments[$choice]
        }
        Write-Warning "Invalid Choice!"
    }
}

function Read-TargetEnvironmentValidForLocalDeployment {
    param(
        [Parameter(Mandatory = $true)]
        [string]
        $ConfigurationPath
    )

    Write-Host ""
    Write-InformationColored "The below list only contains (lower) environments which are valid for local deployments." -ForegroundColor DarkYellow
    Write-InformationColored "Please check/set the property `"ValidForLocalTransport`" for any environments specified in the Configuration.json." -ForegroundColor DarkYellow
	
    return Read-TargetEnvironment `
        -ConfigurationPath $ConfigurationPath `
        -Filter {
        param($environment)

        $valid = $environment.ValidForLocalTransport
        if ($null -eq $valid) {
            return $false
        }

        return $valid
    }
}

function Set-KeyInDictionary {
    param($Dictionary, $Key, $Value)

    if ($Dictionary.Contains($Key)) {
        $Dictionary[$Key] = $Value
    }
    else {
        $Dictionary.Add($Key, $Value)
    }
}

function Get-ReplacementStringsForDataImport {
    param($Config, $Environment, $AdditionalReplacementStrings)

    $replacementStrings = @{}

    # Get parameters 
    $Config.GlobalParameters.PSObject.Properties | ForEach-Object { (Set-KeyInDictionary -Dictionary $replacementStrings -Key ("{" + $_.Name + "}") -Value $_.Value) }
    
    ($Config.Environments.PSObject.Properties | Where-Object { $_.Name -eq $Environment }).Value.Parameters.PSObject.Properties | ForEach-Object { (Set-KeyInDictionary -Dictionary $replacementStrings -Key ("{" + $_.Name + "}") -Value $_.Value) }

    # Include additional replacement string (typically used to add secure parameters from a pipeline)
    foreach ($keyValuePair in $AdditionalReplacementStrings.GetEnumerator()) {
        Set-KeyInDictionary -Dictionary $replacementStrings -Key $keyValuePair.Name -Value $keyValuePair.Value
    }

    return $replacementStrings
}

function Import-DataIntoEnvironment {
    param($ConnectionString, $Config, $Environment, $BasePath, $AdditionalReplacementStrings)

    # Create dictionary for replacement strings by adding global and environment-specific configuration parameters
    $replacementStrings = Get-ReplacementStringsForDataImport -Config $Config -Environment $Environment -AdditionalReplacementStrings $AdditionalReplacementStrings

    # Import configuration data (relevant for all environments)
    Import-Data -ConnectionString $ConnectionString -ConfigurationXml "$BasePath/Data/ConfigurationData.xml" -ImportFile "$BasePath/Data/ConfigurationData" -ReplacementStrings $replacementStrings -UseHash -InformationAction Continue

    # Import remaining data files (as configured for the environment)
    ($config.Environments.PSObject.Properties | Where-Object { $_.Name -eq $Environment }).Value.DataFiles | Where-Object { ![string]::IsNullOrEmpty($_) } | ForEach-Object {
      Import-Data -ConnectionString $ConnectionString -ConfigurationXml "$BasePath/Data/$($_).xml" -ImportFile "$BasePath/Data/$($_)" -ReplacementStrings $replacementStrings -UseHash -InformationAction Continue 
    }
}

function Invoke-DeploymentWithGlobalParameters {
    param($ConfigurationXmlFile, $ConfigurationJsonLocation, $Environment, $AdditionalGlobalParameters)

    # Add standard global parameters to find Configuration.json and to know the desired environment
    $globalParameters = @{ 
        ConfigurationLocation = $ConfigurationJsonLocation
        Environment = $Environment
    }

    # Include additional global parameters (typically used to add secure parameters from a pipeline)
    foreach ($keyValuePair in $AdditionalGlobalParameters.GetEnumerator()) {
        Set-KeyInDictionary -Dictionary $globalParameters -Key $keyValuePair.Name -Value $keyValuePair.Value
    }

    Invoke-Deployment -ConfigurationXmlFile "$ConfigurationXmlFile" -GlobalParameters $globalParameters
}

function Invoke-PreDeploymentSteps {
    param($ConfigurationJsonLocation, $Environment, $BasePath, $GlobalParameters = @{})

    Invoke-DeploymentWithGlobalParameters `
        -ConfigurationXmlFile "$BasePath/Deployment/DPA/PreSteps.xml" `
        -ConfigurationJsonLocation $ConfigurationJsonLocation `
        -Environment $Environment `
        -AdditionalGlobalParameters $GlobalParameters
}

function Invoke-PostDeploymentSteps {
    param($ConfigurationJsonLocation, $Environment, $BasePath, $GlobalParameters = @{})

    Invoke-DeploymentWithGlobalParameters `
        -ConfigurationXmlFile "$BasePath/Deployment/DPA/PostSteps.xml" `
        -ConfigurationJsonLocation $ConfigurationJsonLocation `
        -Environment $Environment `
        -AdditionalGlobalParameters $GlobalParameters
}

function Write-Header {
    param($BlockName)

    Write-InformationColored "`n==========================================="
    Write-InformationColored "==> " -NoNewLine
    Write-InformationColored "$BlockName" -ForegroundColor Cyan
    Write-InformationColored "===========================================`n"
}

function Write-Exception{
    param ($Context)
    $Exception = $Context.Exception
    $strTrace = $Context.ScriptStackTrace

    Write-Host "`n`n`nError occured!" -ForegroundColor Red
    Write-Host "Exception: $($Exception.Message)" -ForegroundColor Red
    Write-Host "StackTrace: $($strTrace)" -ForegroundColor Red
}

function Get-SolutionForType {
    param([string] $Path, [string] $Type)

    Write-Host "Trying to get solution for solution type `"$Type`""
    $solutions = Get-CodeSolutions -Path $Path 
    $solution = $solutions.$Type

    if ($null -eq $solution) {
        throw "Solution with type `"$Type`" not found in EnvironmentConfig at `"$Path`""
    }

    return $solution
}

function Get-CodeSolutions {
    param([string] $Path)

    Write-Host "Trying to get solutions from `"$Path`""
    $config = Get-FrameworkConfiguration -Path $Path
    return $config.CodeSolutions
}

function Invoke-BuildSolution {
    param($SolutionFolder)

    if (!(Test-Path $SolutionFolder)) {
        throw "A CDS project can't be found for solution $SolutionName. Please create a new solution using the CLI"
        Exit 1
    }

    Assert-NuGetIsInstalled

    Write-Information " "
    Write-Information "Building solution: $SolutionFolder"
    
    Set-Location $SolutionFolder

    nuget restore | Write-Verbose

    dotnet build -c Release --source "https://api.nuget.org/v3/index.json" | Write-Verbose

    Write-InformationColored "Solution build finished!`n`n" -ForegroundColor Green

    $zipFiles = Get-ChildItem -Path "$SolutionFolder/bin/Release/" -Filter "*.zip"

    return $zipFiles | Where-Object { $_.Fullname -match "^((?!managed).)*\.zip$" } | Select-Object -ExpandProperty Fullname
}

function Import-CdsSolution {
    param([string] $ConfigurationPath, [string] $EnvironmentName, [string] $SolutionPath)

    Write-Information "Importing solution: $SolutionPath"

    $connStr = Get-ConnectionString `
        -ConfigurationPath $ConfigurationPath `
        -EnvironmentName $EnvironmentName

    Connect-Dataverse `
        -ConnectionString $connStr

    Import-SolutionAsync `
        -SolutionLocation $SolutionPath `
        -OverwriteUnmanagedCustomizations:$true `
        -SkipImportForSameOrHigherSolutionVersion:$true `
        -InformationAction Continue
}

function Format-Json([Parameter(Mandatory, ValueFromPipeline)][String] $json) {
    $indent = 0;
    ($json -Split "`n" | ForEach-Object {
        if ($_ -match '[\}\]]\s*,?\s*$') {
            # This line ends with ] or }, decrement the indentation level
            $indent--
        }
        $line = ('  ' * $indent) + $($_.TrimStart() -replace '":  (["{[])', '": $1' -replace ':  ', ': ')
        if ($_ -match '[\{\[]\s*$') {
            # This line ends with [ or {, increment the indentation level
            $indent++
        }
        $line
    }) -Join "`n"
}


Import-Module (Get-DPACmdletLocation) -Force -Scope Global -ErrorAction Continue
Import-Module "$PSScriptRoot/tool-check.psm1"