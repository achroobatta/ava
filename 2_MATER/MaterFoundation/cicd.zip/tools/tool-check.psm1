

$KnownDependencies = @{
    "nodejs" = { return Test-Command -Executable "node" -TestCommand "node -v" }
    "git" = { return Test-Command -Executable "git" -TestCommand "git --version" }
    "pac" = { return Test-Command -Executable "pac" -TestCommand "pac help" }
    "dotnet" = { return Test-Command -Executable "dotnet" -TestCommand "dotnet --version" }
}

function Test-Command {
    param(
        [Parameter(Mandatory=$true)]
        [string]
        $Executable,

        [Parameter(Mandatory=$true)]
        [string]
        $TestCommand
    )

    $command = Get-Command $Executable -ErrorAction SilentlyContinue
    if($null -eq $command) { return $false }

    $success = $true
    try { 
        Invoke-Expression $TestCommand | Write-Verbose
    } catch { $success = $false }

    if($LASTEXITCODE -ne 0) { $success = $false }

    return $success
}

function Test-Dependencies 
{
    param (
        [Parameter(Mandatory=$true, Position=0)]
        [ValidateSet("nodejs", "git", "pac", "dotnet")]
        [string[]]
        $DependencyNames,

        [bool]
        $PrintHelpAndExistOnFailure = $true
    )

    $result = $true
    foreach ($dependency in $DependencyNames) {
        $innerResult = Test-Dependency -DependencyName $dependency -PrintHelpAndExistOnFailure $PrintHelpAndExistOnFailure
        $result = $result -and $innerResult
    }
}

function Test-Dependency {
    param (
        [Parameter(Mandatory=$true, Position=0)]
        [ValidateSet("nodejs", "git", "pac", "dotnet")]
        [string]
        $DependencyName,

        [bool]
        $PrintHelpAndExistOnFailure = $true
    )

    $dependencySatisfied = Invoke-Command -ScriptBlock $KnownDependencies[$DependencyName]
    if ($dependencySatisfied) { return $true }
    if ($PrintHelpAndExistOnFailure -eq $false) { return $false }

    Write-Host -ForegroundColor Red "You are missing at least one tool that is required to run this script."
    Write-Host -ForegroundColor Red "The required tool is: " -NoNewline
    Write-Host -ForegroundColor Cyan $DependencyName
    Write-Host -ForegroundColor Red "The tool can be installed automatically following these steps: "
    Write-Host -ForegroundColor Red "- Open a PowerShell Window as Administrator"
    Write-Host -ForegroundColor Red "- Run the 'bizapps-cli.ps1' script in your project directory"
    Write-Host -ForegroundColor Red "- Select the 'SetupLocalDevEnvironment' option"

    exit 1
}

