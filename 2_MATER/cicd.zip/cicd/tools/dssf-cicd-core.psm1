# Utility

function EnsureEmptyFolder {
    param([Parameter(Mandatory = $true)] [string] $Path)

    if(!(Test-Path $Path)) {
        New-Item -ItemType Directory -Path $Path -Force
    }
    #Remove-Item -Path "$SolutionPath\*" -Force -Recurse
    Remove-Item -Path $Path -Force -Recurse -ErrorAction SilentlyContinue |Out-Null
}


function Get-EnvironmentConfig {
    param([string] $Path)

    Write-Host "Loading configuration from Environments.json at `"$Path`""
    $config = Get-Content $path -Raw | ConvertFrom-Json

    return $config
}

function Get-EnvironmentConfigForBranch {
    param(
        [Parameter(Mandatory=$true)]
        [string]
        $BranchName,

        [Parameter(Mandatory=$true)]
        [string]
        $EnvironmentJsonPath
    )

    Write-Host "Loading configuration for branch `"$BranchName`" from Environments.json at `"$EnvironmentJsonPath`""


    $config = Get-EnvironmentConfig -Path $EnvironmentJsonPath
    if(-not $config.Branches.PSObject.Properties.Name -contains $BranchName) {
        throw "No Environments found for branch `"$BranchName`" in file `"$EnvironmentJsonPath`""
    }

    $branchMember = $config.Branches | Get-Member -Name $BranchName
    $branchConfig = $config.Branches | Select-Object -ExpandProperty $branchMember.Name

    return $branchConfig
}


# Environment Config
function Get-ConnectionString {
    param(
        [Parameter(Mandatory=$true)]
        [string]
        $Branch,

        [Parameter(Mandatory=$true)]
        [string]
        $Path,

        [Parameter(Mandatory=$true)]
        [string]
        $Environment
    )

    $BranchName = $Branch; $EnvironmentJsonPath = $Path; $EnvironmentName = $Environment;
    Write-Host "Trying to get connection string for `"$BranchName`" for env `"$EnvironmentName`" from `"$EnvironmentJsonPath`""

    $branchConfig = Get-EnvironmentConfigForBranch -EnvironmentJsonPath $EnvironmentJsonPath -BranchName $BranchName

    if(-not ($branchConfig.Environments.PSObject.Properties.Name -contains $EnvironmentName)) {
        throw "Environment `"$EnvironmentName`" not found for branch `"$BranchName`" in file `"$EnvironmentJsonPath`""
    }

    $envMember = $branchConfig.Environments | Get-Member -Name $EnvironmentName
    $envConfig = $branchConfig.Environments | Select-Object -ExpandProperty $envMember.Name

    $ConnectionString = $envConfig.ConnectionString
    if([string]::IsNullOrEmpty($connectionString)) {
        throw "ConnectionString for `"$EnvironmentName`" for branch `"$BranchName`" is empty"
    }
    
    return $ConnectionString
}

function Get-SolutionName {
    param([string] $Path, [string] $Type)

    $solution = Get-Solution -Path $Path -Type $Type
    return $solution.Name
}

function Get-Solution {
    param([string] $Path, [string] $Type)

    Write-Host "Trying to get solution for solution type `"$Type`""
    $solutions = Get-Solutions -Path $Path 
    $solution = $solutions | 
        Where-Object { $_.Type -eq $Type } | 
        Select-Object -First 1

    if($null -eq $solution) {
        throw "Solution with type `"$Type`" not found in EnvironmentConfig at `"$Path`""
    }

    return $solution
}

function Get-Solutions {
    param([string] $Path, [int] $StartPriority = 0, [int] $EndPriority = 9999)

    Write-Host "Trying to get solutions from `"$Path`""
    $config = Get-EnvironmentConfig -Path $Path
    return $config.Solutions | Where-Object { 
        ($_.Priority -ge $StartPriority) -and ($_.Priority -lt $EndPriority)
    } | Sort-Object -Property Priority
}


# NuGet
function Get-InstalledNuGetPackageVersion {
    param([string] $CSProjectPath, [string] $PackageName)

    if (!(Test-Path $CSProjectPath)) {
        throw "The C# project at location `"$CSProjectPath`" could not be found!"
    }

    [xml] $doc = Get-Content $CSProjectPath
    foreach ($node in $doc.DocumentElement.GetElementsByTagName("PackageReference")) {
        $cPackageName = $node.Attributes["Include"].Value
        if($cPackageName -eq $PackageName) {
            $version = $node.Attributes["Version"].Value
            if($null -eq $version) {
                $version = $node.ChildNodes[0].InnerText
            }

            return $version
        }
    }

    throw "Unable to find PackageReference for `"$PackageName`" in `"$CSProjectPath`""
}

function Get-NuGetPackageToolPath {
    param([string] $PackageName, [string] $PackageVersion, [string] $NugetConfigPath, [string] $ToolPath)

    Write-Verbose "Getting nuget tool path:"
    Write-Verbose "PackageName: $PackageName"
    Write-Verbose "PackageVersion: $PackageVersion"
    Write-Verbose "NugetConfigPath: $NugetConfigPath"
    Write-Verbose "ToolPath: $ToolPath"

    $NugetGlobalPackagePath = (nuget locals global-packages -list).Substring(17)
    Write-Verbose "Nuget global package path: $NugetGlobalPackagePath"

    $PackagePath = [System.IO.Path]::Combine($NugetGlobalPackagePath, $PackageName, $PackageVersion)
    Write-Verbose "Package path: $PackagePath"

    if(!(Test-Path $PackagePath)) {
        Write-Information "Installing nuget package."
        nuget install $PackageName -Version $PackageVersion -OutputDirectory $NugetGlobalPackagePath -ConfigFile $NugetConfigPath | Out-Null
    }

    $FullToolPath = [System.IO.Path]::Combine($PackagePath, $ToolPath)
    if(!(Test-Path $FullToolPath)) {
        throw "Unable to find tool `"$FullToolPath`""
    }

    return $FullToolPath
}

function Get-NuGetPackageToolPathEasy {
    param([string] $PackageName, [string] $NugetConfigPath, [string] $ToolPath, [string] $CSProjectPath)

    Write-Verbose "Getting nuget tool path (easy):"
    Write-Verbose "PackageName: $PackageName"
    Write-Verbose "NugetConfigPath: $NugetConfigPath"
    Write-Verbose "ToolPath: $ToolPath"
    Write-Verbose "CSProjectPath: $CSProjectPath"

    $version = Get-InstalledNuGetPackageVersion -CSProjectPath $CSProjectPath -PackageName $PackageName
    Write-Verbose "Nuget Package version: $version"

    $resolvedPath = Get-NuGetPackageToolPath -PackageName $PackageName -PackageVersion $version -NugetConfigPath $NugetConfigPath -ToolPath $ToolPath
    Write-Verbose "Path to nuget package: $resolvedPath"

    return $resolvedPath
}

# Solutions
function Expand-CrmSolution {
    param(
        [string] $SolutionPath, 
        [string] $SolutionName, 
        [string] $BasePath, 
        [string] $NugetConfigPath = "$BasePath\NuGet.config",
        [string] $CSProjectPath = $null
    )

    $TargetPackageName = "Microsoft.CrmSdk.CoreTools"
    
    if($null -eq $CSProjectPath) {
        $projectFiles = Get-ChildItem -Path $BasePath -Filter "*.EntryPoint.csproj" -Recurse
        if ($projectFiles.count -ne 1) {
            throw "Can't determine EntryPoint project."
        }
            
        $CSProjectPath = $projectFiles[0].FullName
    }

    $toolPath = Get-NuGetPackageToolPathEasy `
        -PackageName $TargetPackageName `
        -NugetConfigPath $NugetConfigPath `
        -ToolPath "content\bin\coretools\SolutionPackager.exe" `
        -CSProjectPath $CSProjectPath

    $UnpackPath =  "$BasePath\Deployment\Solutions\$SolutionName"
    EnsureEmptyFolder -Path $UnpackPath

    $command = $toolPath
    $command += " /action:Extract"
    $command += " /zipfile:`"$SolutionPath`""
    $command += " /folder:`"$UnpackPath`""

    try {
        Write-Host "Removing any .dll file in the extracted solution"
        Get-ChildItem -Path $UnpackPath -Filter *.dll -Recurse | Remove-Item
    } catch { }

    Invoke-Expression $command
}

function Compress-CrmSolution {
    param([string] $UnpackedPath, [string] $PackedPath, [string] $CSProjectPath, [string] $NugetConfigPath = "$BasePath\NuGet.config")

    $TargetPackageName = "Microsoft.CrmSdk.CoreTools"
		
    $toolPath = Get-NuGetPackageToolPathEasy `
        -PackageName $TargetPackageName `
        -NugetConfigPath $NugetConfigPath `
        -ToolPath "content\bin\coretools\SolutionPackager.exe" `
        -CSProjectPath $CSProjectPath

    $command = $toolPath
    $command += " /action:Pack"
    $command += " /zipfile: $PackedPath"
    $command += " /folder: $UnpackedPath"

    $command | Invoke-Expression
}


function Get-NextSolutionVersion {
    param([string] $ConnectionString, [string] $SolutionName, [string] $BaseVersion)
    
    $solution = Get-XrmSolution `
        -ConnectionString "$ConnectionString" `
        -UniqueSolutionName $SolutionName

    $oldVersion = [version]::Parse($solution.Version)
    $newVersionBase = [version]::Parse($BaseVersion)
    $newVersion = "0.0.1"
    if($newVersionBase.Major -gt $oldVersion.Major -or ($newVersionBase.Major -eq $oldVersion.Major -and $newVersionBase.Minor -gt $oldVersion.Minor)) {
        $newVersion = "$BaseVersion.0"
    } elseif($newVersionBase.Major -eq $oldVersion.Major -and $newVersionBase.Minor -eq $oldVersion.Minor) {
        $newVersion = "$($oldVersion.Major).$($oldVersion.Minor).$($oldVersion.Build + 1)"
    } else {
        Write-Error "BaseVersion from Environments.json is older than the current installed version"
    }

    Write-Host "SolutionName: $SolutionName, InstalledVersion: $oldVersion, VersionBase: $newVersionBase, NewVersion: $newVersion"

    return $newVersion
}

function Test-CrmSolutionExistsInGit {
    param([string] $BasePath, [string] $SolutionName)

    $path = Join-Path $BasePath $SolutionName

    $customizationsExists = Test-Path "$path/Other/Customizations.xml"
    $relationshipsExist   = Test-Path "$path/Other/Relationships.xml"
    $solutionExists       = Test-Path "$path/Other/Solution.xml"

    return $customizationsExists -and $relationshipsExist -and $solutionExists
}


Export-ModuleMember -Function Get-InstalledNuGetPackageVersion
Export-ModuleMember -Function Get-NuGetPackageToolPath
Export-ModuleMember -Function Get-NuGetPackageToolPathEasy

Export-ModuleMember -Function Get-EnvironmentConfig
Export-ModuleMember -Function Get-EnvironmentConfigForBranch
Export-ModuleMember -Function Get-ConnectionString
Export-ModuleMember -Function Get-SolutionName
Export-ModuleMember -Function Get-Solution
Export-ModuleMember -Function Get-Solutions
Export-ModuleMember -Function Get-NextSolutionVersion

Export-ModuleMember -Function Expand-CrmSolution
Export-ModuleMember -Function Compress-CrmSolution

Export-ModuleMember -Function Test-CrmSolutionExistsInGit
