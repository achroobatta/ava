# bicep-templates

Put BICEP templates here.