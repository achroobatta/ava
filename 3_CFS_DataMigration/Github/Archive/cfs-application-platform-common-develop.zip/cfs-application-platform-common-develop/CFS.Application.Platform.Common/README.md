# CFS.Application.Platform.Common.csproj
