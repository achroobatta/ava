# cfs-application-platform-common\CFS.Application.Platform.Common\scripts

Folder for scripts
