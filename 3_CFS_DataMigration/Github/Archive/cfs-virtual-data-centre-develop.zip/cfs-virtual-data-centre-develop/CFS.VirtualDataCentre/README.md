# CFS.VirtualDataCentre.csproj
